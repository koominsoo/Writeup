package org.dimigo.gui;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.security.Key;
import java.util.List;

public class Controller {
    @FXML private Label lbl_TITLE;
    @FXML private TextArea txt_LISTALL;
    @FXML private TextArea txt_PASTALL;
    @FXML private TextArea txt_TEAMRANK;
    @FXML private Button btn_GOBACK1;
    @FXML private Button btn_GOBACK2;
    @FXML private Button btn_GOBACK3;

    @FXML
    public void upcomingList(ActionEvent event) {
        try
        {
            Document doc = Jsoup.connect("https://ctftime.org/event/list/upcoming").get();
            Elements elements = doc.select("tr").select("td");
            List<String> upcomingctfs = elements.eachText();

            String[][] data = new String[15][6];
            int idx = 0;
            for (int i=0; i<15; i++) // display max 15
            {
                for (int j=0; j<6; j++)
                {
                    data[i][j] = upcomingctfs.get(idx++);
                }
            }

            String res = "";

            for (int i=0; i<15; i++) {
                res += ("+-------- 대회 " + (i+1) + " --------+\n");
                res += ("대회명    : " + data[i][0]+"\n");
                res += ("일시      : " + data[i][1]+"\n");
                res += ("대회 방식 : " + data[i][2]+"\n");
                res += ("장소      : " + data[i][3]+"\n");
                res += ("난이도    : " + data[i][4]+"\n");
                res += ("참가 팀수 : " + data[i][5].substring(0,data[i][5].indexOf("teams")));
                if (i!=14) res += "\n\n";

            }
            txt_LISTALL.setText(res);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @FXML
    public void pastList(ActionEvent event) {
        try
        {
            Document doc = Jsoup.connect("https://ctftime.org/event/list/past").get();
            Elements elements = doc.select("tr").select("td");
            List<String> pastctfs = elements.eachText();
            String[][] data = new String[15][5];
            int idx = 0;
            for (int i=0; i<15; i++) // display max 15
            {
                for (int j=0; j<5; j++)
                {
                    data[i][j] = pastctfs.get(idx++);
                    if (pastctfs.get(idx).indexOf("missing") > -1) idx++;
                }
            }
            String res = "";
            for (int i=0; i<15; i++) {
                res += ("+-------- 대회 " + (i+1) + " --------+\n");
                res += ("대회명    : " + data[i][0]+"\n");
                res += ("일시      : " + data[i][1]+"\n");
                res += ("대회 방식 : " + data[i][2]+"\n");
                res += ("장소      : " + data[i][3]+"\n");
                res += ("난이도    : " + data[i][4]);
                if (i!=14) res += "\n\n";
            }
            txt_PASTALL.setText(res);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @FXML
    public void teamList(ActionEvent event) {
        try
        {
            Document doc = Jsoup.connect("https://ctftime.org/stats/").get();
            Elements elements = doc.select("tr").select("td");


            List<String> teamranks = elements.eachText();


            String[][] data = new String[15][5];
            int idx = 0;
            for (int i=0; i<15; i++) // display max 15
            {
                for (int j=0; j<4; j++)
                {
                    data[i][j] = teamranks.get(idx++);
                }
            }
            String res = "";
            System.out.println("+-------- 해킹 팀 순위 --------+\n");
            for (int i=0; i<15; i++) {
                res += data[i][0] + "위 : " + data[i][1] + " (" + data[i][2] + "점)";
                if (i!=14) res += "\n\n";
            }
            txt_TEAMRANK.setText(res);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void goBack1(ActionEvent event) throws IOException{
        Stage stage = (Stage) btn_GOBACK1.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/dimigo/gui/mainscreen.fxml"));

        Parent root = loader.load();
        Scene scene = new Scene(root, 990, 760);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }
    public void goBack2(ActionEvent event) throws IOException{
        Stage stage = (Stage) btn_GOBACK2.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/dimigo/gui/mainscreen.fxml"));

        Parent root = loader.load();
        Scene scene = new Scene(root, 990, 760);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }
    public void goBack3(ActionEvent event) throws IOException{
        Stage stage = (Stage) btn_GOBACK3.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/dimigo/gui/mainscreen.fxml"));

        Parent root = loader.load();
        Scene scene = new Scene(root, 990, 760);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    public void handleListAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) lbl_TITLE.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/dimigo/gui/listall.fxml"));

        Parent root = loader.load();
        Scene scene = new Scene(root, 990, 760);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    public void handlePastAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) lbl_TITLE.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/dimigo/gui/pastall.fxml"));

        Parent root = loader.load();
        Scene scene = new Scene(root, 990, 760);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }
    public void handleTeamRankAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) lbl_TITLE.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/dimigo/gui/teamrank.fxml"));

        Parent root = loader.load();
        Scene scene = new Scene(root, 990, 760);
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }
}
